Compile instructions:
Go to the parent folder of the project folder (which should be named codegen) and run "javac -cp ./:codegen/json.jar codegen/CodeGenerator.java"

Run instructions:
Go to the parent folder of the project folder (which should be named codegen) and run "java -cp ./:codegen/json.jar codegen.Codegenerator $fileName $language"